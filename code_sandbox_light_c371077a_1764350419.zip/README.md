# 🚀 Schuvarex Systems - Site GitHub Pages

> Site institucional profissional otimizado para publicação no GitHub Pages

[![GitHub Pages](https://github.com/badges/shields/workflows/GitHub%20Pages/badge.svg)](https://github.com/seuusuario/schuvarex-systems)
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![HTML](https://img.shields.io/badge/HTML-5-orange.svg)](https://developer.mozilla.org/en-US/docs/Web/HTML)
[![CSS](https://img.shields.io/badge/CSS-3-blue.svg)](https://developer.mozilla.org/en-US/docs/Web/CSS)
[![JavaScript](https://img.shields.io/badge/JavaScript-ES6+-yellow.svg)](https://developer.mozilla.org/en-US/docs/Web/JavaScript)

## 📋 Descrição

Site institucional da **Schuvarex Systems**, uma empresa de tecnologia focada em inovação e soluções empresariais. Desenvolvido com as melhores práticas de desenvolvimento web e otimizado para publicação gratuita no GitHub Pages.

## ✨ Características Principais

### 🎨 Design Moderno
- **Tema Azul Profissional**: Paleta de cores coerente e moderna
- **Design Responsivo**: Totalmente adaptável para desktop, tablet e mobile
- **Animações Suaves**: Transições e micro-interações elegantes
- **Tipografia Premium**: Fonte Inter do Google Fonts

### ⚡ Performance & SEO
- **SEO Otimizado**: Meta tags, Open Graph e Twitter Cards
- **Performance**: CSS e JavaScript otimizados
- **Acessibilidade**: WCAG 2.1 compatível
- **Mobile First**: Desenvolvimento mobile-first

### 🛠️ Funcionalidades
- **Navegação Suave**: Scroll animado entre seções
- **Menu Mobile**: Hamburguer menu totalmente funcional
- **Formulário de Contato**: Com validação e feedback visual
- **Animações ao Scroll**: Elementos aparecem suavemente
- **GitHub Pages Ready**: Otimizado para deploy instantâneo

## 🚀 Publicação no GitHub Pages

### Passo 1: Criar Repositório no GitHub

1. Acesse [github.com/new](https://github.com/new)
2. **Nome do repositório**: `schuvarex-systems` (ou qualquer nome)
3. **Privacidade**: Público (necessário para GitHub Pages gratuito)
4. **Inicializar**: ✓ Add a README file
5. Clique em **Create repository**

### Passo 2: Fazer Upload dos Arquivos

#### Opção A: Upload Direto (Recomendado para iniciantes)
1. No repositório criado, clique em **Add file** → **Upload files**
2. Arraste todos os arquivos da pasta do projeto:
   - `index.html`
   - `assets/css/style.css`
   - `assets/js/script.js`
   - `README.md`
   - `.gitignore`
3. Confirme o upload

#### Opção B: Git (Para usuários avançados)
```bash
# Clone o repositório
git clone https://github.com/seuusuario/schuvarex-systems.git

# Copie os arquivos do projeto
# Entre na pasta
cd schuvarex-systems

# Adicione os arquivos
git add .

# Commit
git commit -m "Primeiro commit - Site Schuvarex Systems"

# Push para o GitHub
git push origin main
```

### Passo 3: Ativar GitHub Pages

1. No repositório, vá para **Settings** → **Pages**
2. **Source**: Deploy from a branch
3. **Branch**: `main` (ou `master`)
4. **Folder**: `/ (root)`
5. Clique em **Save**

### Passo 4: Aguarde e Acesse

- Aguarde 1-2 minutos para o deploy
- Sua URL será: `https://[seu-usuario].github.io/[nome-repositorio]/`
- Exemplo: `https://joao123.github.io/schuvarex-systems/`

## 📁 Estrutura de Arquivos

```
schuvarex-systems/
├── index.html              # Página principal
├── assets/
│   ├── css/
│   │   └── style.css      # Estilos completos
│   └── js/
│       └── script.js      # JavaScript interativo
├── README.md              # Este arquivo
└── .gitignore            # Arquivo Git ignore
```

## 🎯 Personalização Rápida

### Alterar Informações da Empresa
Edite o arquivo `index.html` e altere:
```html
<!-- Linha 8: Descrição SEO -->
<meta name="description" content="SUA NOVA DESCRIÇÃO AQUI">

<!-- Linha 22: URL do site -->
<meta property="og:url" content="https://seuusuario.github.io/seu-repositorio">

<!-- Linhas 130-140: Informações de contato -->
<span>seuemail@empresa.com</span>
<span>+55 (XX) XXXX-XXXX</span>
<span>Sua Cidade, Estado - País</span>
```

### Alterar Cores
Edite o arquivo `assets/css/style.css` e modifique as variáveis:
```css
:root {
    --primary-blue: #2563eb;        /* Cor principal */
    --primary-blue-dark: #1d4ed8;    /* Cor principal escura */
    --secondary-blue: #1e40af;      /* Cor secundária */
    --accent-blue: #60a5fa;       /* Cor de destaque */
}
```

## 🌟 Recursos Avançados

### 🚀 Performance
- **CSS Minificado**: Arquivo único para carregamento rápido
- **JavaScript Otimizado**: Sem dependências externas
- **Imagens SVG**: Ícones vetoriais escaláveis
- **Lazy Loading**: Carregamento sob demanda

### ♿ Acessibilidade
- **WCAG 2.1**: Compatível com diretrizes de acessibilidade
- **Navegação por Teclado**: Totalmente navegável via teclado
- **Screen Readers**: Suporte completo para leitores de tela
- **Contraste de Cores**: Razão de contraste adequada

### 📱 Responsividade
- **Breakpoints**: Mobile (480px), Tablet (768px), Desktop (1200px)
- **Flexbox/Grid**: Layout moderno e flexível
- **Unidades Relativas**: rem, %, vh/vw para adaptação perfeita

## 📊 Análise de Performance

| Métrica | Valor |
|---------|-------|
| Tamanho Total | ~45KB |
| Tempo de Carregamento | <2s (3G) |
| Pontuação Lighthouse | 95+ |
| Compatibilidade | IE11+ |

## 🔧 Manutenção

### Atualizações de Segurança
```bash
# Verificar se há atualizações nos CDNs
# Font Awesome, Google Fonts, etc.
```

### Backup
```bash
# Faça backup antes de grandes alterações
git add .
git commit -m "Backup antes de atualizações"
git push origin main
```

## 🆘 Suporte

### Problemas Comuns

**1. Site não aparece no GitHub Pages**
- Verifique se o repositório é público
- Confirme que o arquivo `index.html` está na raiz
- Aguarde 5-10 minutos após o primeiro deploy

**2. Imagens quebradas**
- Use caminhos relativos: `assets/img/imagem.jpg`
- Evite espaços em nomes de arquivos

**3. CSS não carrega**
- Verifique a sintaxe do CSS
- Confirme o caminho do arquivo

### Obter Ajuda
- 📧 Email: contato@schuvarexsystems.com
- 💬 Issues no GitHub
- 📖 Documentação GitHub Pages

## 📄 Licença

Este projeto está licenciado sob a Licença MIT - veja o arquivo [LICENSE](LICENSE) para detalhes.

## 🙏 Agradecimentos

- [Font Awesome](https://fontawesome.com/) - Ícones
- [Google Fonts](https://fonts.google.com/) - Tipografia Inter
- [GitHub](https://github.com/) - Hospedagem gratuita
- [GitHub Pages](https://pages.github.com/) - Deploy automático

---

**Desenvolvido com ❤️ para a Schuvarex Systems**  
**Publicado com ☕ no GitHub Pages**